import os
import ast
import time
import json
import shutil
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/', methods=['POST', 'GET'])
def index():
            if request.method == 'POST':

                final=request.data
                beta=ast.literal_eval(str(final))


                def fetch_keys(data):
                        for i in data.keys():
                                if type(data[i])==list:
                                        for b in data[i]:
                                                fetch_keys(b)
                                elif type(data[i])==dict:
                                        #for j in data[i].keys():
                                                #data[i][j]=''
                                        fetch_keys(data[i])
                                else:
                                        data[i]=''
                fetch_keys(beta)
                print json.dumps(beta, sort_keys=True, indent=8)

                with open('/home/punechha/flask_project/output.json', 'w') as output:
                        json.dump(beta, output, sort_keys=True, indent=8)


                return jsonify({'json skeleton created' : 'and exported'})

            else:
                return jsonify({'get_method':'kindly switch to post method to perform json skeleton operation'})

if __name__=='__main__':
        app.run(debug=True)