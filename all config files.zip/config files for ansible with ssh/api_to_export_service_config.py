from zipfile import ZipFile
import os
import ast
import time
import json
import shutil
from flask import Flask, request, redirect, url_for
from flask import jsonify, send_file

app = Flask(__name__)

@app.route('/', methods=['POST', 'GET'])
def index():
            if request.method == 'POST':


                final=request.data                #taking input from user, fetching the data from uploaded file
                beta=ast.literal_eval(str(final)) #converting json into python string and then into python dictionary


                def fetch_all_keys(data, arr):    #recursive function to fetch all the keys from nested dictionary
                        for i in data.keys():
                                if type(data[i])==list:
                                        for b in data[i]:
                                                fetch_all_keys(b, arr)
                                elif type(data[i])==dict:
                                        fetch_all_keys(data[i], arr)
                                if type(data[i]) == str:
                                        arr.append(i)
                        return arr
                def fetch_primary_keys(data, arr): #function to fetch all primary keys or keys at level 1 from nested dictionary
                        for i in data.keys():
                                if type(data[i])==str:
                                        arr.append(i)
                        return arr


                list1 = []
                list2 = []
                alpha = fetch_all_keys(beta, list1) #list of all keys
                var1 = fetch_primary_keys(beta, list2) #list of primary keys



                def makedict(arr): #function to generate config.json string format(python)
                        def beautify(i): #function to generate names from parameter by removing '_'
                                str=''
                                for a in range(len(i)):
                                        if a==0:
                                                str+=i[a].upper()
                                        else:
                                                if i[a]=='_':
                                                        str+=' '
                                                else:
                                                        str+=i[a]
                                return str

                        beta = []
                        for i in arr:
                            temp = {'id': str(i), 'name': beautify(str(i)), 'binding': str(i), 'required': True, 'editable': True, 'hidden': False, 'inputType': 'freeText'}
                                beta.append(temp)
                        return beta



                var2 = {'id': 'PLAYBOOK', 'name': 'PLAYBOOK', 'description': 'PLAYBOOK', 'providerCode': 'aws', 'provider': { 'name': 'AWS', 'code': 'aws' }, 'version': '1.0.0', 'isOrderLifeCycleRequired': False, 'serviceType': 'ServiceOperation', 'isPricingEnabled': True, 'isConfigurationEnabled': True, 'associatedTo': { 'type': 'SOC', 'providerSOCTypeIds': [] }, 'routing_key': 'aws', 'context': { 'organization': [], 'team': [],  'application': [], 'environment': [] }, 'status': 'PUBLISHED', 'isCustom': True, 'operationTimeout': 0, 'operationCode': 'PLAYBOOK', 'collection': 'services', 'serviceCategory': [] }
                # variable containing service.json string format(python)


                with open('/home/punechha/flask_project/config.json', 'w') as output:
                        json.dump(makedict((set(alpha)-set(var1))), output, sort_keys=False, indent=8)
                #exporting files to config and service to be in json format
                with open('/home/punechha/flask_project/service.json', 'w') as output:
                        json.dump(var2, output, sort_keys=False, indent=8)


                zipObj = ZipFile('/home/punechha/flask_project/service+config.zip', 'w')
                #creating a zip file and zipping the service and config file
                zipObj.write('/home/punechha/flask_project/config.json')
                zipObj.write('/home/punechha/flask_project/service.json')

                zipObj.close()
                #returning the zip file
                print '************************************************'
                print '*************OPERATION COMPLETED****************'
                print '************************************************'
                return send_file('/home/punechha/flask_project/service+config.zip')
            else:
                return jsonify({'get_method':'kindly switch to post method to perform json skeleton operation'})

if __name__=='__main__':
        app.run(debug=True)