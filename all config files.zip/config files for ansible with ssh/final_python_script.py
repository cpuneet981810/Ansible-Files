import time
import json
import shutil
from ansible.module_utils.common.collections import ImmutableDict
from ansible.parsing.dataloader import DataLoader
from ansible.vars.manager import VariableManager
from ansible.inventory.manager import InventoryManager
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.plugins.callback import CallbackBase
from ansible import context
import ansible.constants as C
print
print '1. Start'
time.sleep(1)
print '2. Stop'
time.sleep(1)
print '3. Reboot'
time.sleep(1)
print '4. Get Virtual Machine\'s IP Address'
time.sleep(1)
print
alpha = raw_input('Enter option 1, 2, 3 or 4 | Enter any other option to exit : ')

# since the API is constructed for CLI it expects certain options to always be set in the context object
context.CLIARGS = ImmutableDict(module_path=['/to/mymodules'], forks=10, become=None,
                                become_method=None, become_user=None, check=False, diff=False, inventory_path=['/etc/ansible/hosts'])

# initialize needed objects
loader = DataLoader() # Takes care of finding and reading yaml, json and ini files
passwords = dict(vault_pass='secret')
# create inventory, use path to host config file as source or hosts in a comma separated string
inventory = InventoryManager(loader=loader, sources='akhilaws,')

# variable manager takes care of merging all the different sources to give you a unified view of variables available in each context
variable_manager = VariableManager(loader=loader, inventory=inventory)

# create data structure that represents our play, including tasks, this is basically what our YAML loader does internally.
if alpha=='1':
        play_source =  dict(
                name = "Start",
                hosts = 'akhilaws',
                connection = 'local',
                tasks = [
                    dict(action=dict(module='ec2', args=dict(aws_access_key='AKIAI3DEZEGNKK3WTFFQ', aws_secret_key='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', instance_type='t2.micro', vpc_subnet_id='vpc-583efd31', image='ami-0ebbf2179e615c338', region='us-east-2', key_name='Interns', state='running', instance_ids='i-0b7ca4b790357709e')))])
elif alpha=='2':
        play_source =  dict(
                name = "Stop",
                hosts = 'akhilaws',
                connection = 'local',
                tasks = [
                dict(action=dict(module='ec2', args=dict(aws_access_key='AKIAI3DEZEGNKK3WTFFQ', aws_secret_key='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', instance_type='t2.micro', vpc_subnet_id='vpc-583efd31', image='ami-0ebbf2179e615c338', region='us-east-2', state='stopped', key_name='Interns', instance_ids='i-0b7ca4b790357709e')))])
elif alpha=='3':
       play_source =  dict(
        name = "Reboot",
        hosts = 'akhilaws',
        connection = 'local',
        tasks = [
            dict(action=dict(module='ec2', args=dict(aws_access_key='AKIAI3DEZEGNKK3WTFFQ', aws_secret_key='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', instance_type='t2.micro', vpc_subnet_id='vpc-583efd31', image='ami-0ebbf2179e615c338', region='us-east-2', state='restarted', key_name='Interns', instance_ids='i-0b7ca4b790357709e')))])

elif alpha=='4':
        play_source = dict(
         name = "Get IP",
         hosts = 'akhilaws',
         connection = 'local',
         tasks = [
                  dict(action=dict(module='shell', args='aws ec2 describe-instances --instance-ids i-0b7ca4b790357709e --region us-east-2 --query \'Reservations[*].Instances[*].PublicIpAddress\' --output text'), register='new_ip_address'),
                  dict(action=dict(module='debug', args=dict(var='new_ip_address.stdout')))])
else:
        exit()
# Create play object, playbook objects use .load instead of init or new methods,
# this will also automatically create the task objects from the info provided in play_source
play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
# Run it - instantiate task queue manager, which takes care of forking and setting up all objects to iterate over host list and tasks
tqm = None
try:
         tqm = TaskQueueManager(
              inventory=inventory,
              variable_manager=variable_manager,
              loader=loader,
              passwords=passwords,
#              stdout_callback=results_callback,  # Use our custom callback instead of the ``default`` callback plugin, which prints to
 stdout
             )
         result = tqm.run(play) # most interesting data for a play is actually sent to the callback's methods
finally:
    # we always need to cleanup child procs and the structures we use to communicate with them
    if tqm is not None:
        tqm.cleanup()

    # Remove ansible tmpdir
    shutil.rmtree(C.DEFAULT_LOCAL_TMP, True)